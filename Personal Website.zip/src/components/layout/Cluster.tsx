import type { ComponentProps, ElementType, ReactNode } from "react";
import { cn } from "@/lib/cn";

type ClusterGap = "sm" | "md" | "lg";
type ClusterJustify = "start" | "center" | "end" | "between";
type ClusterAlign = "start" | "center" | "end";

interface ClusterProps extends ComponentProps<"div"> {
  as?: ElementType;
  gap?: ClusterGap;
  justify?: ClusterJustify;
  align?: ClusterAlign;
  className?: string;
  children: ReactNode;
}

const gapClass: Record<ClusterGap, string> = {
  sm: "gap-2",
  md: "gap-4",
  lg: "gap-6",
};

const justifyClass: Record<ClusterJustify, string> = {
  start: "justify-start",
  center: "justify-center",
  end: "justify-end",
  between: "justify-between",
};

const alignClass: Record<ClusterAlign, string> = {
  start: "items-start",
  center: "items-center",
  end: "items-end",
};

/** Horizontal, wrapping flex layout with consistent gap. For groups that
 *  should flow and wrap naturally — tag lists, button groups, badges.
 *  Accepts arbitrary HTML attributes and ref (React 19: ref is a regular
 *  prop, no forwardRef needed) via rest spread. */
export function Cluster({
  as: Component = "div",
  gap = "md",
  justify = "start",
  align = "center",
  className,
  children,
  ref,
  ...rest
}: ClusterProps) {
  return (
    <Component
      ref={ref}
      className={cn(
        "flex flex-wrap",
        gapClass[gap],
        justifyClass[justify],
        alignClass[align],
        className
      )}
      {...rest}
    >
      {children}
    </Component>
  );
}
